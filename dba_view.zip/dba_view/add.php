<style>
table.ano {
        font-family: verdana,arial,sans-serif;
        font-size:11px;
        color:#333333;
        border-width: 1px;
        border-color: #666666;
        border-collapse: collapse;
}
table.ano th {
        border-width: 1px;
        padding: 8px;
        border-style: solid;
        border-color: #666666;
        background-color: #dedede;
}
table.ano td {
        border-width: 1px;
        padding: 8px;
        border-style: solid;
        border-color: #666666;
        background-color: #ffffff;
}
</style>

<?php
include("include/ini.php");
include("include/dbconnect.php");
include("include/function.php");

$k = 0;
$m = 0;
$p = 0;
$id = 0;
$demo = "";

$list_notes = array();
$value = array();

date_default_timezone_set("Asia/Hong_Kong");

$list_notes = notes();

$filed_name = array();
	
if(isset($_GET['web']))
{
    $web = $_GET['web'];
}
else
{
    $web = "";	
}
if(isset($_GET['sea']))
{
	$sea = $_GET['sea'];
}
else
{
    $sea = "";	
}
if(isset($_GET['file']))
{	
    $file = $_GET['file'];
}
else
{
    $file = "";	
}
if(isset($_GET['fil']))
{
	$fil = $_GET['fil'];
}
else
{
	$fil = "";
}

if(isset($_GET['edit_id']))
{
	$id = $_GET['edit_id'];
}

	$list = display($web,$list_notes,1);
			
	$filed = mysql_query("select COLUMN_NAME from information_schema.COLUMNS where table_name = '$list'");
	while($filed_list = mysql_fetch_array($filed, MYSQL_ASSOC))
	{
		$filed_name[$k] = $filed_list['COLUMN_NAME'];
		$k++;
	}
	
	if($id)
	{
		$filed_value = mysql_query("select * from `$web` where `id` = '$id'");
		$filed_result = mysql_fetch_array($filed_value, MYSQL_ASSOC);
		for($s = 0; $s < count($filed_result); $s++)
		{
			if($filed_name[$s] == 'enter_time')
			{
			    $value[$s] = date('Y-m-d H:i:s',time());
			}
			else
			{
	   	 	$value[$s] = $filed_result[$filed_name[$s]];	
			}
		}		
	}
	
	if($list)
	{
		echo "<br><table border='1' class='ano'>";     		
	   	if($id)
		{
			echo "<tr><th>&nbsp;编辑操作&nbsp;</th>"; 
		}
		else
		{
			echo "<tr><th>&nbsp;添加操作&nbsp;</th>"; 
		}
		
	for($i = 0; $i < count($filed_name); $i++)
	{
	    echo "<th>$filed_name[$i]</th>";	
	}
	echo "</tr><tr>";
	$filed_name[$i] = $web;
	$filed_name[$i + 1] = $id;
	$filed_name[$i + 2] = $sea;
	$filed_name[$i + 3] = $fil;
	$filed_name[$i + 4] = $file;
	
	$str=json_encode($filed_name);
	if($id)
	{
		echo "<td align='center'><button style='width:140px; height:30px; background-color:pink;' onclick='updata_data($str)'>提交</button></td>";
	}
	else
	{
		echo "<td align='center'><button style='width:140px; height:30px; background-color:pink;' onclick='insert_data($str)' >提交</button></td>";
	}
	if($id)
	{
		for($j = 0; $j < $k - 1; $j++)
		{
		    echo "<td><input type='text' value='$value[$j]' id='$filed_name[$j]' placeholder='请输入$filed_name[$j]' style='height:30px'></input></td>";	
		}
		    echo "<td><input type='text' value='$value[$j]' id='$filed_name[$j]' onkeypress='if(event.keyCode==13){updata_data($str);}' placeholder='请输入$filed_name[$j]' style='height:30px' ></input></td>";	
	}
	else
	{
	for($j = 0; $j < $k - 1; $j++)
		{
		    if($filed_name[$j] == 'enter_time')
			{
			    $time = date('Y-m-d H:i:s',time());
			}
			else
			{
				$time = "";
			}	
		
		    echo "<td><input type='text' value='$time' id='$filed_name[$j]' placeholder='请输入$filed_name[$j]' style='height:30px'></input></td>";	
		}
		    if($filed_name[$j] == 'enter_time')
			{
			    $time = date('Y-m-d H:i:s',time());
			}
			else
			{
				$time = "";
			}	
			echo "<td><input type='text' value='$time' id='$filed_name[$j]' onkeypress='if(event.keyCode==13){insert_data($str);}' placeholder='请输入$filed_name[$j]' style='height:30px' ></input></td>";	

	}
	echo "</tr></table>";
	
}

?>
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script type="text/JavaScript"> 

function updata_data(name)
{
    var sql = "UPDATE `"+name[name.length - 5]+"` SET";
	var i = 0;
	
	for(var i = 0; i < name.length - 6; i++)
	{
		var input = document.getElementById(name[i]).value;
	    sql = sql+"`"+name[i]+"`='"+input+"',";
	}
	if(i == name.length - 6)
	{
		var input = document.getElementById(name[i]).value;
	    sql = sql+"`"+name[i]+"`='"+input+"'";
	}
	
	sql = sql + " "+"where `id` = '"+name[i+2]+"'";
	
	window.location.href = "write_log.php?edit_sql="+sql+"&web="+name[i+1]+"&sea="+name[i+3]+"&file="+name[i+5]+"&fil="+name[i+4];
}

function insert_data(name)
{
    var sql = "INSERT INTO `"+name[name.length - 5]+"`(";
	var i = 0;
	
	for(var i = 0; i < name.length - 6; i++)
	{
	    sql = sql+"`"+name[i]+"`,";
	}
	if(i == name.length - 6)
	{
	    sql = sql+"`"+name[i]+"`)";
	}

sql = sql+" VALUES (";

for(var i = 0; i < name.length - 6; i++)
	{
		var input = document.getElementById(name[i]).value;
	    sql = sql+"'"+input+"',";
	}
	if(i == name.length - 6)
	{
		var input = document.getElementById(name[i]).value;
	    sql = sql+"'"+input+"')";
	}
	
	window.location.href = "write_log.php?insert_sql="+sql+"&web="+name[i+1]+"&sea="+name[i+3]+"&file="+name[i+5]+"&fil="+name[i+4];
}

$("#selectId").change(function()
{
	window.location.href= "login.php?web="+$("#selectId").val();			
}
);

</script>

