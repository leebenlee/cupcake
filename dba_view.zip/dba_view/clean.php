<?php

$fd = fopen("log.txt","w+");
fclose($fd);

?>
