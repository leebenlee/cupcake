<?php

$name = "yunwei";

$link = mysql_connect("10.10.88.176", "root", "moresmarTV@608") or die("Could not connect: " . mysql_error());

mysql_select_db($name,$link);


?>
