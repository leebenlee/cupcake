        <style type="text/css">

#title_first{
font-size:14px;
margin-left:22px; 
float:left;
}

            /*SELECT W/DOWN-ARROW*/
            select#selectId
            {
		margin-top:36px;
		margin-left:-120px;		 
				  float:left;
               height:30px;
               line-height              : 40pt;
               box-shadow               : inset 0 0 3px #606060;
               border                   : 1px solid #acacac;
               -moz-border-radius       : 6px;
               -webkit-border-radius    : 6px;
               appearance               : none;
               font-family              : Arial,  Calibri, Tahoma, Verdana;    
               color                    : steelblue;
}      

</style>
<?php

function list_get()
{
	$sql = "show table status from yunwei";
	$result = mysql_query($sql);
	
	return $result;
}

function display($li,$notes,$ed)
{
	$flag = 0;
$result_list = list_get(); 

$rows = mysql_num_rows($result_list);

echo "<p id='title_first'>请选择数据库列表</p>";
echo "<select id='selectId'>";
echo "<option value=''></option>";
for($j = 0; $j < $rows; $j++)
{
	$list_name = mysql_result($result_list,$j);

	if($li)
	{
		if($list_name == $li)
		{
			echo "<option value=$list_name selected='selected'>$list_name</option>"; 
			$list = $list_name;
			$flag = $j+1;
		}
		else
		{
			echo "<option value=$list_name>$list_name</option>";
		}
	}
	else
	{
		echo "<option value=$list_name>$list_name</option>";
	
	}
	
}
echo "</select>";

if($flag)
{
	echo "<p style='float:left; margin-top:40px; margin-left:10px; font-size:14px; font-weight:bold; float:left;'>".$notes[$flag-1]."</p>";
}
if($ed)
{
	echo "<p style='float:left; margin-top:70px; margin-left:-250px; font-size:14apx; font-weight:bold'>编辑模式下，若更换列表查询信息将清空！</p>";
}

if(!$li)
{
    return 0;	
}

return $list;

}

function paging($web,$query,$select,$list,$filed,$file,$fil,$sea,$sql_on,$group)
{    
	$PageSize = 20;
	$amount = 0;
  
if($group)
{
	$result = mysql_query($query);

	while(mysql_fetch_row($result))
	{
	    $amount++;
	}//$row的结果集是个数组，它的值是7，表明数据库中共有7条数据记录。
}
else
{
	$result = mysql_query($query);

	$row = mysql_fetch_row($result);
	$amount = $row[0];
}
     //计算共有多少页
if($amount)
{   //$PageCount表示总共有多少页。
    if($amount<$PageSize)
	{
		$PageCount = 1;
	}//如果总数据量小于每页数量则总页数为1
    if($amount%$PageSize)
	{
        $PageCount = (int)($amount/$PageSize)+1;
    }
    else
	{
        $PageCount = $amount/$PageSize;
    }
}
else
{
    $PageCount = 0;
}
        
        //获取当前页数
if(isset($_GET['page']))
{
    $page = intval($_GET['page']);
}
else
{   
    $page = 1;
}
         
$up_l =  ($page-1)*$PageSize;
$limit="limit $up_l,$PageSize";//注意limit后边有一空格。
$sql = $select." ".$limit;

$result = mysql_query($sql);
         
echo "<div id='here'>";
for($i=0;$i<$amount;$i++)
{
    while($row = mysql_fetch_assoc($result))
	{
		 echo "<tr>";
	 $flag = $row[$filed[0]];
		 echo "<td align='center'><button onclick='delete_row($flag)' id='delete_bt'></button><button onclick='edit($flag)' id='edit_bt'></button></td>";
		
for($z = 0; $z < count($filed); $z++)
	{	
		echo "<td class='userNameTd' align='center';>".$row[$filed[$z]]."</td>";
	}
	echo "</tr>";
    }
}

echo "</div></table><br></div>";  
        
        //翻页链接
$PageString = '';//用来保存要转到的页数按钮。
        
if($page==1)
{    //不能写成$page=1
    $PageString = '首页|上一页|';
}
else
{ 
    $PageString ='<a href="?page=1&sql='.$sql_on.'&web='.$web.'&sea='.$sea.'&file='.$file.'&fil='.$fil.'">首页</a>|<a href="?sql='.$sql_on.'&page='.($page-1).'&web='.$web.'&sea='.$sea.'&file='.$file.'&fil='.$fil.'">上一页</a>|';
}

echo $PageString;   

if(($page==$PageCount)||($PageCount==0))
{
    $PageString = '<font color="red">下一页|尾页</font>';
}
else
{
    $PageString ='<a href="?sql='.$sql_on.'&page='.($page+1).'&web='.$web.'&sea='.$sea.'&file='.$file.'&fil='.$fil.'">下一页</a>|<a href="?sql='.$sql_on.'&page='.$PageCount.'&web='.$web.'&sea='.$sea.'&file='.$file.'&fil='.$fil.'">尾页</a>';
}

echo $PageString;
$number = $PageCount * $PageSize;
echo "<br><br>共有".$page."/".$PageCount."页\t".$amount."条记录.";

}

function notes()
{

    $list_notes = array();

    $list_notes[0] = "服务器管理表";
    $list_notes[1] = "应用和发布系统对应表";
    $list_notes[2] = "cdn域名服务器对应表";
    $list_notes[3] = "cdn提供商的标识表";
    $list_notes[4] = "鉴黄记录表";
    $list_notes[5] = "数据等级记录表";
    $list_notes[6] = "验证结果表";
    $list_notes[7] = "验证数据表";
    $list_notes[8] = "dnspod域名服务器对应表";
    $list_notes[9] = "事件记录表";
    $list_notes[10] = "FTP信息表";
    $list_notes[11] = "用户名密码对应表";
    $list_notes[12] = "订单支付信息汇总表";
    $list_notes[13] = "端口信息表";
    $list_notes[14] = "端口进程对应表";
    $list_notes[15] = "项目db对应表";
    $list_notes[16] = "环境进程对应";
    $list_notes[17] = "程序发布表";
    $list_notes[18] = " ";
    $list_notes[19] = "服务器申请记录表";
    $list_notes[20] = "服务器详细信息表";
    $list_notes[21] = "服务关系表";
    $list_notes[22] = "mysql权限表";
    $list_notes[23] = "mysql信息表";
    $list_notes[24] = "标准端口进程列表";
    $list_notes[25] = "服务器标准信息表";
    $list_notes[26] = "mysql语句记录表";
    $list_notes[27] = "版本发布记录表";
    $list_notes[28] = "nginx域名服务器对应表";
    $list_notes[29] = "whaley出口列表";

    return $list_notes;
}

?>
