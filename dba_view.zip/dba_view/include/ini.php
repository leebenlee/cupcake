<?php

    $the_day = "`enter_time` regexp DATE_SUB(CURDATE(),INTERVAL 0 day)";
    $condition = "order by `enter_time` DESC";
    $que = "select count(*) as amount from ";
    $sel = "select * from "; 

    $no_time_list = array("standard_server");
    $today_list = array("all_server","server_detail","scan_info","sql_info","port_info");
?>
