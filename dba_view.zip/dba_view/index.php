<html lang="zh_CN">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<?php

define('ADMIN_USERNAME','admin');

define('ADMIN_PASSWORD','whaley');

if (!isset($_SERVER['PHP_AUTH_USER']) ||

   !isset($_SERVER['PHP_AUTH_PW']) ||

    $_SERVER['PHP_AUTH_USER'] != ADMIN_USERNAME || 

    $_SERVER['PHP_AUTH_PW'] != ADMIN_PASSWORD) {

        Header('WWW-Authenticate: Basic realm="Login"');

        Header('HTTP/1.0 401 Unauthorized');
 

        echo <<<EOB

                <html><body>

                <h1>Rejected!</h1>

                <big>Wrong Username or Password!</big>

                </body></html>

EOB;

        exit;

}

include("login.php");

?>
</head>
