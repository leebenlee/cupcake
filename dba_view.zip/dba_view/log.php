<html lang="zh_CN">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<?php

$content = file_get_contents("log.txt");
$log_a = explode("\n", $content);

echo "<p style='font-weight:bold; font-size:22px'>数据库操作日志（保留时间：7天）</p>";
echo "<br>";

echo "<table border='1'>";
for($i = 0; $i < count($log_a); $i++)
{
    echo "<tr><td>";
    echo $log_a[$i];
    echo "</td></tr>";
}
echo "</table>";

?>
</head>
