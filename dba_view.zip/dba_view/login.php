<style>
#add_bt{
	width:34px;
	height:34px;
	margin-left:10px;
background-color:transparent;	
background-image:url(http://pic.sucaibar.com/pic/201307/19/7a34332ef1_32.png);
}
#delete_bt{
	width:34px;
	height:34px;
	background-color:transparent;
background-image:url(http://pic.sucaibar.com/pic/201307/20/96d3d2f9ff_32.png);
border:0px solid
}
#edit_bt{
	width:34px;
	height:34px;

	background-color:transparent;
	background-image:url(http://pic.sucaibar.com/pic/201306/26/9fd222a4ea_32.png);
border:0px solid
}

#box2{position:relative}

#box2 #box1{position:absolute;left:0;top:0}

table.gridtable {
	font-family: verdana,arial,sans-serif;
	font-size:11px;
	color:#333333;
	border-width: 1px;
	border-color: #666666;
	border-collapse: collapse;
}
table.gridtable th {
	border-width: 1px;
	padding: 8px;
	border-style: solid;
	border-color: #666666;
	background-color: #dedede;
}
table.gridtable td {
	border-width: 1px;
	padding: 8px;
	border-style: solid;
	border-color: #666666;
	background-color: #ffffff;
}
</style>
<title>cmdb数据库</title>
<div>
<?php

echo "<a style='float:left; font-size:16px; margin-right:10px; margin-top:10px;' href='' onclick='check_log()'>操作日志</a> ";

include("include/ini.php");
include("include/dbconnect.php");
include("include/function.php");

$k = 0;
$m = 0;
$demo = " ";

$list_notes = notes();
$filed_name = array();

date_default_timezone_set("Asia/Hong_Kong");
$time = date('Y-m-d H:i:s',time());

if(isset($_GET['delete_flag']))
{
	$judge =  $_GET['delete_flag'];
	if($judge == 1)
	{
	       echo "<script LANGUAGE='javascript'>alert('Delete successed!');</script>"; 
	}
	else
	{
	       echo "<script LANGUAGE='javascript'>alert('Delete error!');</script>"; 	
		}
	
}
if(isset($_GET['insert_flag']))
{
	$judge =  $_GET['insert_flag'];
	if($judge == 1)
	{
	       echo "<script LANGUAGE='javascript'>alert('Insert successed!');</script>"; 
	}
	else
	{
	       echo "<script LANGUAGE='javascript'>alert('Insert error!');</script>"; 	
		}
	
}
if(isset($_GET['edit_flag']))
{
	$judge =  $_GET['edit_flag'];
	if($judge == 1)
	{
	       echo "<script LANGUAGE='javascript'>alert('Edit successed!');</script>"; 
	}
	else
	{
	       echo "<script LANGUAGE='javascript'>alert('Edit error!');</script>"; 	
		}
	
}

if(isset($_GET['sea']))
{
	$sea = $_GET['sea'];
}
else
{
    $sea = 0;	
}
if(isset($_GET['file']))
{	
    $file = $_GET['file'];
}
else
{
    $file = 0;	
}
if(isset($_GET['fil']))
{
	$fil = $_GET['fil'];
}
else
{
	$fil = 0;
}
if(isset($_GET['web']))
{
    $web = $_GET['web'];
}
else
{
    $web = 0;	
}
if(isset($_GET['sql']))
{
    $sql = $_GET['sql'];
}
else
{
    $sql = 0;
}

for($e_t = 0; $e_t < count($no_time_list); $e_t++)
{
    if($web == $no_time_list[$e_t])
    {
	
	$condition = " ";
//	echo $condition."<br>foolish<br>";
    }
}

//echo $condition."<br>";
for($t_t = 0; $t_t < count($today_list); $t_t++)
{
	if($web == $today_list[$t_t])
	{
		if($file || $sea)
		{
			$condition = " ".$the_day." ".$condition;
			$condition = " and ".$condition;
		}
		else if($sql)
		{
			$condition = " and ".$the_day." ".$condition;
			$condition = " ".$condition;
		}
		else
		{	
			$condition = " ".$the_day." ".$condition;
			$condition = " where ".$condition;
		}
	}
}
if($sql)
{       
        echo "<div style='float:right;'>SQL  :  ".$sql."</div>\t";
        
        $condition = $sql." ".$condition;
        $str2 = 'group by';
        
        if(strpos($sql,$str2) === false){
             $group_flag = 0;
        }else{
            $group_flag = 1;
        }
}


	$list = display($web,$list_notes,0);
			
	$filed = mysql_query("select COLUMN_NAME from information_schema.COLUMNS where table_name = '$list'");
	while($filed_list = mysql_fetch_array($filed, MYSQL_ASSOC))
	{
		$filed_name[$k] = $filed_list['COLUMN_NAME'];
		$k++;
	}
	
	if($list)
	{
		echo "<br><br><br><div id='box1'>";
echo "<p></p><br>";
		echo "<select id='selectField' style='width:120px; height:30px;'>";
		echo "<option >请选择搜索字段</option>";
		for($j = 0; $j < count($filed_name); $j++)
		{
			if($fil)
			{
				if($filed_name[$j] == $fil)
				{
					echo "<option value=$filed_name[$j] value=$filed_name[$j] selected='selected'>$filed_name[$j]</option>";	
				}
				else
				{
					echo "<option value=$filed_name[$j] value=$filed_name[$j]>  $filed_name[$j]</option>";
				}
			}
			else
			{
				echo "<option value=$filed_name[$j]>$filed_name[$j]</option>";
			}
		}
		if($file && $sea)
		{
			echo "<input type='text' value=$file style='width:160px;height:30px;align:center' id='felid' onkeypress='if(event.keyCode==13){listen_field();}'/>";   
			echo "<input type='text' value=$sea style='width:160px;height:30px;align:center;' id='text' onkeypress='if(event.keyCode==13){listen_key();}'/>";   
       			 
		}
		else if($file && !$sea)
		{
			echo "<input type='text' value=$file style='width:160px;height:30px;align:center' id='felid' onkeypress='if(event.keyCode==13){listen_field(;}'/>";   
			echo "<input type='text' placeholder='全文搜索回车确认' style='width:160px;height:30px; align:center;' id='text' onkeypress='if(event.keyCode==13){listen_key();}'/>";   
        }
		else if($sea && !$file)
		{
			echo "<input type='text' placeholder='请输入字段内容回车确认' style='width:160px;height:30;align:centerpx;' id='felid' onkeypress='if(event.keyCode==13){listen_field();}'/>";   
			echo "<input type='text' value=$sea style='width:160px;height:30px;align:center;' id='text' onkeypress='if(event.keyCode==13){listen_key();}'/>";   
        }
		else
		{
			echo "<input type='text' placeholder='请输入字段内容回车确认' style='width:160px;height:30px;align:center' id='felid' onkeypress='if(event.keyCode==13){listen_field();}'/>";   
			echo "<input type='text' placeholder='全文搜索回车确认' style='width:160px;height:30px;align:center;' id='text' onkeypress='if(event.keyCode==13){listen_key();}'/>";   			
        }		

	echo "<button onclick='add()' id='add_bt'></button>添加记录";

if($sql)
{	
	echo "<input type='text' value='$sql' placeholder='sql语句查询，请输入select * from table后的语句' style='width:320px;height:30px;align:center;float:right;' id='sql' onkeypress='if(event.keyCode==13){listen_key();}'/>";   			
}
else
{
	echo "<input type='text' placeholder='sql语句查询，请输入select * from table后的语句' style='width:320px;height:30px;align:center;float:right;' id='sql' onkeypress='if(event.keyCode==13){listen_key();}'/>";   			

}
		echo "</div><br>";
		echo "<div id='box2'><table border='1' class='gridtable'>";
		echo "</td></tr>";
	   	echo "<tr><th><div style='width:120px;'>操作</div></th>"; 
		
	for($i = 0; $i < $k; $i++)
	{
	    echo "<th>$filed_name[$i]</th>";	
	}
	echo "</tr>";
	
	for($p = 0; $p < count($filed_name); $p++)
	{
		if($p == (count($filed_name)-1))
		{
			$demo = $demo."`".$filed_name[$p]."`";
		}
		else
		{
			$demo =  $demo."`".$filed_name[$p]."`,";	
		}
	}

	if($file && $fil && $sea)
	{	
		$condition = "where concat(".$demo.") like '%".$sea."%' and `".$fil."` like '%".$file."%'"." ".$condition;		
	}
	else if($file && $fil && !$sea)
	{
		$condition = "where `".$fil."` like '%".$file."%'"." ".$condition;
	}
	else if(!$file && !$fil && $sea)
	{
		$condition = "where concat(".$demo.") like '%".$sea."%'"." ".$condition;		
	}
	else if(!$file && $fil && $sea)
	{
		$condition = "where concat(".$demo.") like '%".$sea."%'"." ".$condition;		
	}
	
	if(isset($_GET['edit_id']))
	{
		$id = $_GET['edit_id'];
		$condition = $condition." where `id` =".$id;	
	}
	
	$query = "select count(*) as amount from ".$web." ".$condition;
	$select = "select * from ".$web." ".$condition;	

//echo $query."<br>".$select."<br>".$condition;
    
	paging($web,$query,$select,$list,$filed_name,$file,$fil,$sea,$sql,$group_flag);
}
	
?>

</div>

<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script type="text/JavaScript"> 

function check_log()
{
	window.open("log.php");
}

function add()
{
	if(confirm("确定要添加吗？"))
	{
		window.location.href= "add.php?web="+$("#selectId").val()+"&sea="+$('#text').val()+"&file="+$('#felid').val()+"&fil="+$("#selectField").val();
      		return true;
    	}
	else
	{
        	return false;
	}
}

function delete_row(id)
{
	var fil = id;
	if(confirm("确定要删除吗？"))
	{
	  	window.location.href= "write_log.php?delete_id="+fil+"&web="+$("#selectId").val()+"&sea="+$('#text').val()+"&file="+$('#felid').val()+"&fil="+$("#selectField").val();
      		
		return true;
        }
	else
	{
        	return false;
    	}
}

function edit(id)
{
		var fil = id;
		if(confirm("确定要更改吗？")){
		window.location.href= "add.php?edit_id="+fil+"&web="+$("#selectId").val()+"&sea="+$('#text').val()+"&file="+$('#felid').val()+"&fil="+$("#selectField").val();
	     return true;
	    }else{
   	     return false;
   		}
}

function listen_key()
{
	window.location.href= "?sql="+$("#sql").val()+"&web="+$("#selectId").val()+"&sea="+$('#text').val()+"&file="+$('#felid').val()+"&fil="+$("#selectField").val();
}


function listen_field()
{
	window.location.href= "?web="+$("#selectId").val()+"&sea="+$('#text').val()+"&file="+$('#felid').val()+"&fil="+$("#selectField").val();
}
	
$("#selectId").change(function()
{
	window.location.href= "?web="+$("#selectId").val(); 			
}
);
$("#selectField").change(function()
{
	window.location.href= "?web="+$("#selectId").val()+"&file="+$('#felid').val()+"&fil="+$("#selectField").val()+"&sea="+$('#text').val();			
}
);

</script>
