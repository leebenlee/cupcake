<?php
include("include/dbconnect.php");

date_default_timezone_set("Asia/Hong_Kong");
$time = date('Y-m-d H:i:s',time());

if(isset($_GET['sea']))
{
	$sea = $_GET['sea'];
}
else
{
    $sea = 0;	
}
if(isset($_GET['file']))
{	
    $file = $_GET['file'];
}
else
{
    $file = 0;	
}
if(isset($_GET['fil']))
{
	$fil = $_GET['fil'];
}
else
{
	$fil = 0;
}
if(isset($_GET['web']))
{
    $web = $_GET['web'];
}
else
{
    $web = 0;	
}
if(isset($_GET['delete_id']))
{
	$id = $_GET['delete_id'];

	$delete_sql = "DELETE FROM `".$web."` WHERE `id` = ".$id;	

	$que=mysql_query($delete_sql); 
	if($que) 
	{
		$fn = "log.txt";
		$fd = fopen($fn,'a+');
		$log = "成功\t丨\t".$time."\t丨\t".$delete_sql."\n";
		fwrite($fd,$log);
		fclose($fd);
		
		$flag = 1;
		header("location:login.php?delete_flag=".$flag."&web=".$web."&sea=".$sea."&file=".$file."&fil=".$fil);
	}
	else
	{ 
		$fn = "log.txt";
                $fd = fopen($fn,'a+');
                $log = "失败\t丨\t".$time."\t丨\t".$delete_sql."\n";
                fwrite($fd,$log);
                fclose($fd);

		$flag = 0;
		header("location:login.php?delete_flag=".$flag."&web=".$web."&sea=".$sea."&file=".$file."&fil=".$fil);
	}
	
	
}

if(isset($_GET['edit_sql']))
{	
	$edit_sql = $_GET['edit_sql'];
	$edit_result = mysql_query($edit_sql); 
	if($edit_result) 
	{
		$fn = "log.txt";
		$fd = fopen($fn,'a+');
		$log = "成功\t丨\t".$time."\t丨\t".$edit_sql."\n";
		fwrite($fd,$log);
		fclose($fd); 
		$flag = 1;		    		
		header("location:login.php?edit_flag=".$flag."&web=".$web."&sea=".$sea."&file=".$file."&fil=".$fil);
	}
	else 
	{
		$fn = "log.txt";
                $fd = fopen($fn,'a+');
                $log = "失败\t丨\t".$time."\t丨\t".$edit_sql."\n";
                fwrite($fd,$log);
                fclose($fd); 

		$flag = 0;		    		
		header("location:login.php?edit_flag=".$flag."&web=".$web."&sea=".$sea."&file=".$file."&fil=".$fil);
	}		
	
	
}

if(isset($_GET['insert_sql']))
{	
	$insert_sql = $_GET['insert_sql'];
	$insert_result = mysql_query($insert_sql); 
		
	if($insert_result) 
	{
		$fn = "log.txt";
		$fd = fopen($fn,'a+');
		$log = "成功\t丨\t".$time."\t丨\t".$insert_sql."\n";
		fwrite($fd,$log);
		fclose($fd); 
		$flag = 1;		    		
		header("location:login.php?insert_flag=".$flag."&web=".$web."&sea=".$sea."&file=".$file."&fil=".$fil);
	}
	else 
	{
		$fn = "log.txt";
                $fd = fopen($fn,'a+');
                $log = "失败\t丨\t".$time."\t丨\t".$insert_sql."\n";
                fwrite($fd,$log);
                fclose($fd); 
		$flag = 0;		    		
		header("location:login.php?insert_flag=".$flag."&web=".$web."&sea=".$sea."&file=".$file."&fil=".$fil);
	}
	
}
            
?>
